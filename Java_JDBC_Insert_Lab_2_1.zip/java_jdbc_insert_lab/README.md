# JDBC Insert Data — Experiment 2.1

## Aim
Connect to MySQL database `mydatabase`, create the `users` table if needed, and insert two records using `PreparedStatement`.

## File
- `JDBCInsertDemo.java`

## Before running
1. Start MySQL.
2. Create the database once:
   ```sql
   CREATE DATABASE IF NOT EXISTS mydatabase;
   ```
3. Replace `your_password` in the Java file with your MySQL password.
4. Add MySQL Connector/J to your project's classpath/dependencies.

The program creates the `users` table automatically.

## Run
Compile and run after configuring the MySQL JDBC driver:

```bash
javac JDBCInsertDemo.java
java -cp ".:/path/to/mysql-connector-j.jar" JDBCInsertDemo
```

Replace `/path/to/mysql-connector-j.jar` with the actual JAR path. On Windows, use `;` instead of `:` in the classpath.

## Expected output
```text
Data inserted successfully.
```

## Important
Each run inserts two additional rows. The program intentionally uses the specified hardcoded values and does not clear existing records. Do not commit real database passwords to a public GitHub repository.
