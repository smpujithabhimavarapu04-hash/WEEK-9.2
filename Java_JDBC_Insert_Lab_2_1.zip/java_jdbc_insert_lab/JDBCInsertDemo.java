import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class JDBCInsertDemo {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/mydatabase";
    private static final String USERNAME = "root";
    // Replace with your own MySQL password.
    private static final String PASSWORD = "your_password";

    public static void main(String[] args) {
        String createTableSql =
                "CREATE TABLE IF NOT EXISTS users ("
                + "id INT PRIMARY KEY AUTO_INCREMENT, "
                + "name VARCHAR(100) NOT NULL, "
                + "email VARCHAR(200) NOT NULL)";

        String insertSql = "INSERT INTO users (name, email) VALUES (?, ?)";

        try (Connection connection =
                     DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
             PreparedStatement createTableStatement =
                     connection.prepareStatement(createTableSql)) {

            createTableStatement.executeUpdate();

            try (PreparedStatement insertStatement =
                         connection.prepareStatement(insertSql)) {
                insertStatement.setString(1, "John Doe");
                insertStatement.setString(2, "john.doe@example.com");
                insertStatement.executeUpdate();

                insertStatement.setString(1, "Jane Doe");
                insertStatement.setString(2, "jane.doe@example.com");
                insertStatement.executeUpdate();
            }

            System.out.println("Data inserted successfully.");
        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
            System.err.println("Check that MySQL is running, database 'mydatabase' exists, "
                    + "credentials are correct, and MySQL Connector/J is configured.");
        }
    }
}
